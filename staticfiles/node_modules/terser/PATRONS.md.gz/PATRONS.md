# Our patrons

These are the first-tier patrons from [Patreon](https://www.patreon.com/fabiosantoscode). My appreciation goes to everyone on this list for supporting the project!

 * 38elements
 * Alan Orozco
 * Aria Buckles
 * CKEditor
 * Mariusz Nowak
 * Nakshatra Mukhopadhyay
 * Philippe Léger
 * Piotrek Koszuliński
 * Serhiy Shyyko
 * Viktor Hubert
 * 龙腾道
