1.0.2 / 2018-09-20
=================
  * [Refactor] use `has-symbols` and `object-inspect`
  * [Tests] test on all the node minor versions

1.0.1 / 2015-01-26
=================
  * Corrected description

1.0.0 / 2015-01-24
=================
  * Initial release
