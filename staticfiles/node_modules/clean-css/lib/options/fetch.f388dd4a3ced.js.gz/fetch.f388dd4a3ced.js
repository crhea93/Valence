var loadRemoteResource = require('../reader/load-remote-resource');

function fetchFrom(callback) {
  return callback || loadRemoteResource;
}

module.exports = fetchFrom;
