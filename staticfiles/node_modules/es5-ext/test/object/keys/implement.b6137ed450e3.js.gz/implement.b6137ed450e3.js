"use strict";

var isImplemented = require("../../../object/keys/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
