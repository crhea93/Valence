"use strict";

var isImplemented = require("../../../../reg-exp/#/sticky/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
