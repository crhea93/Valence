"use strict";

var isImplemented = require("../../../math/imul/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
