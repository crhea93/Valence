"use strict";

var isImplemented = require("../../../../array/#/fill/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
