"use strict";

var isImplemented = require("../../../../array/#/filter/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
