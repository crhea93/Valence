"use strict";

var isImplemented = require("../../../../array/#/find-index/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
