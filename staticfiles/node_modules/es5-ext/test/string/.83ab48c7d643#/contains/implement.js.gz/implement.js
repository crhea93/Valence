"use strict";

var isImplemented = require("../../../../string/#/contains/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
