module.exports = "The tools we use have a profound (and devious!) influence on our thinking habits, and, therefore, on our thinking abilities.- E. Dijkstra"
