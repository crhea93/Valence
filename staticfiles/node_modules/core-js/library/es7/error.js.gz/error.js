require('../modules/es7.error.is-error');
module.exports = require('../modules/_core').Error;
