var document = require('./_global').document;
module.exports = document && document.documentElement;
