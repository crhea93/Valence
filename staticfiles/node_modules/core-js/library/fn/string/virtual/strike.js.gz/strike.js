require('../../../modules/es6.string.strike');
module.exports = require('../../../modules/_entry-virtual')('String').strike;
