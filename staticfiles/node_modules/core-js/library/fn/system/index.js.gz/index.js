require('../../modules/es7.system.global');
module.exports = require('../../modules/_core').System;
