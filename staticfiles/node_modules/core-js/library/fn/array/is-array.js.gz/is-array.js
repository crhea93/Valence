require('../../modules/es6.array.is-array');
module.exports = require('../../modules/_core').Array.isArray;
