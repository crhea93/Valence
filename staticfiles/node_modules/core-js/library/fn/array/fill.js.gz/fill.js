require('../../modules/es6.array.fill');
module.exports = require('../../modules/_core').Array.fill;
