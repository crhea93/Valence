const set = require('regenerate')();
set.addRange(0x11480, 0x114C7).addRange(0x114D0, 0x114D9);
module.exports = set;
