const set = require('regenerate')(0x1145B);
set.addRange(0x11400, 0x11459).addRange(0x1145D, 0x1145F);
module.exports = set;
