const set = require('regenerate')(0xA9CF);
set.addRange(0x1A00, 0x1A1B).addRange(0x1A1E, 0x1A1F);
module.exports = set;
