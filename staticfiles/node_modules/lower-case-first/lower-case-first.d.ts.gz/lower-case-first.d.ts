declare function lowerCaseFirst (value: string, locale?: string): string;

export = lowerCaseFirst;
