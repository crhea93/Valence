import AwaitValue from "./AwaitValue";
export default function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}