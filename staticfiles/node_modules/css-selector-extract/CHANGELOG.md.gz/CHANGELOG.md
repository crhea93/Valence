`css-selector-extract` uses [GitHub's Releases feature](https://github.com/blog/1547-release-your-software) for its changelogs.

See [the Releases section of our GitHub project](https://github.com/maoberlehner/css-selector-extract/releases) for changelogs for each release version of `css-selector-extract`.
