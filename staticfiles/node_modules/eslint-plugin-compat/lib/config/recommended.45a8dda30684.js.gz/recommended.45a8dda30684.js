"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = {
  plugins: ['compat'],
  env: {
    browser: true
  },
  rules: {
    'compat/compat': 'error'
  }
};
exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb25maWcvcmVjb21tZW5kZWQuanMiXSwibmFtZXMiOlsicGx1Z2lucyIsImVudiIsImJyb3dzZXIiLCJydWxlcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7O2VBQWU7QUFDYkEsRUFBQUEsT0FBTyxFQUFFLENBQUMsUUFBRCxDQURJO0FBRWJDLEVBQUFBLEdBQUcsRUFBRTtBQUNIQyxJQUFBQSxPQUFPLEVBQUU7QUFETixHQUZRO0FBS2JDLEVBQUFBLEtBQUssRUFBRTtBQUNMLHFCQUFpQjtBQURaO0FBTE0sQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IHtcbiAgcGx1Z2luczogWydjb21wYXQnXSxcbiAgZW52OiB7XG4gICAgYnJvd3NlcjogdHJ1ZVxuICB9LFxuICBydWxlczoge1xuICAgICdjb21wYXQvY29tcGF0JzogJ2Vycm9yJ1xuICB9XG59O1xuIl19