"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// TODO: not implemented yet.
const KangaxProvider = [];
var _default = KangaxProvider;
exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9wcm92aWRlcnMvS2FuZ2F4UHJvdmlkZXIuanMiXSwibmFtZXMiOlsiS2FuZ2F4UHJvdmlkZXIiXSwibWFwcGluZ3MiOiI7Ozs7OztBQUdBO0FBQ0EsTUFBTUEsY0FBMkIsR0FBRyxFQUFwQztlQUVlQSxjIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQGZsb3dcbmltcG9ydCB0eXBlIHsgTm9kZSB9IGZyb20gJy4uL0xpbnRUeXBlcyc7XG5cbi8vIFRPRE86IG5vdCBpbXBsZW1lbnRlZCB5ZXQuXG5jb25zdCBLYW5nYXhQcm92aWRlcjogQXJyYXk8Tm9kZT4gPSBbXTtcblxuZXhwb3J0IGRlZmF1bHQgS2FuZ2F4UHJvdmlkZXI7XG4iXX0=