"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.rules = void 0;

var _CanIUseProvider = _interopRequireDefault(require("./CanIUseProvider"));

var _MdnProvider = _interopRequireDefault(require("./MdnProvider"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// eslint-disable-next-line import/prefer-default-export
const rules = [..._CanIUseProvider.default, ..._MdnProvider.default];
exports.rules = rules;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9wcm92aWRlcnMvaW5kZXguanMiXSwibmFtZXMiOlsicnVsZXMiLCJDYW5JVXNlIiwiTWRuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQ0E7O0FBQ0E7Ozs7QUFHQTtBQUNPLE1BQU1BLEtBQWtCLEdBQUcsQ0FBQyxHQUFHQyx3QkFBSixFQUFhLEdBQUdDLG9CQUFoQixDQUEzQiIsInNvdXJjZXNDb250ZW50IjpbIi8vIEBmbG93XG5pbXBvcnQgQ2FuSVVzZSBmcm9tICcuL0NhbklVc2VQcm92aWRlcic7XG5pbXBvcnQgTWRuIGZyb20gJy4vTWRuUHJvdmlkZXInO1xuaW1wb3J0IHR5cGUgeyBOb2RlIH0gZnJvbSAnLi4vTGludFR5cGVzJztcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9wcmVmZXItZGVmYXVsdC1leHBvcnRcbmV4cG9ydCBjb25zdCBydWxlczogQXJyYXk8Tm9kZT4gPSBbLi4uQ2FuSVVzZSwgLi4uTWRuXTtcbiJdfQ==