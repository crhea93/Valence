# get-destructure-identifiers change log

All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

## 1.2.0 / 2018-02-08

* support object rest destructuring `{...a} = b`

## 1.1.0 / 2017-12-02

* support import declarations

## 1.0.0 / 2017-11-11

* initial release
