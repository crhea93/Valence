"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Compat;

var _fs = _interopRequireDefault(require("fs"));

var _path = _interopRequireDefault(require("path"));

var _mdnBrowserCompatData = _interopRequireDefault(require("mdn-browser-compat-data"));

var _ = _interopRequireDefault(require("."));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

async function Compat() {
  const records = await (0, _.default)(); // Add all the corresponding compat data for each inferred ast node

  const compatDataMap = new Map([...Object.entries(_mdnBrowserCompatData.default.api), ...Object.entries(_mdnBrowserCompatData.default.javascript.builtins)]);
  const apisWithCompatRecords = records.filter(api => {
    const hasCompatRecord = compatDataMap.has(api.protoChain[0]);
    if (!hasCompatRecord) return false;

    if (api.protoChain.length >= 2) {
      const item = compatDataMap.get(api.protoChain[0]);
      return api.protoChain[1] in item;
    }

    return true;
  }).map(api => {
    const compatRecord = compatDataMap.get(api.protoChain[0]);
    const {
      __compat: compat
    } = api.protoChain.length >= 2 ? compatRecord[api.protoChain[1]] || compatRecord : compatRecord;
    return { ...api,
      compat: compat || compatRecord
    };
  });

  const compatRecordsFile = _path.default.join(__dirname, '..', 'compat.json');

  await _fs.default.promises.writeFile(compatRecordsFile, JSON.stringify(apisWithCompatRecords));
  return apisWithCompatRecords;
}

if (require.main === module) {
  (async () => {
    await Compat();
  })();
}