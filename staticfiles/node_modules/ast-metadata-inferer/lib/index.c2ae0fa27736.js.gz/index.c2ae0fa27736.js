"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = AstMetadataInferer;

var _fs = _interopRequireDefault(require("fs"));

var _path = _interopRequireDefault(require("path"));

var _providers = _interopRequireDefault(require("./providers"));

var _AstNodeTypeTester = _interopRequireDefault(require("./helpers/AstNodeTypeTester"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

async function AstMetadataInferer() {
  // @HACK: Temporarily ignoring the last 1K records because they
  //        cause issues for some unknown reason. They prevent
  //        AstMetadataInferer from returning
  const records = (await (0, _providers.default)()).slice(0, 13000);
  const promises = [];
  const parallelisim = 4;
  const eachRecordsSize = Math.floor(records.length / parallelisim);

  for (let i = 0; i < parallelisim; i += 1) {
    const recordsSliceEnd = i === parallelisim ? records.length + 1 : (i + 1) * eachRecordsSize;
    const recordsSlice = records.slice(i * eachRecordsSize, recordsSliceEnd);
    promises.push((0, _AstNodeTypeTester.default)(recordsSlice));
  }

  const recordsWithMetadata = await Promise.all(promises).then(res => res.reduce((p, c) => p.concat(c), []));

  const file = _path.default.join(__dirname, '..', 'metadata.json');

  await _fs.default.promises.writeFile(file, JSON.stringify(recordsWithMetadata));
  return recordsWithMetadata;
}