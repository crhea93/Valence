"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MdnComaptDataProvider;

var _mdnBrowserCompatData = _interopRequireDefault(require("mdn-browser-compat-data"));

var _MsApiCatalogProvider = require("../MsApiCatalogProvider");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function MdnComaptDataProvider() {
  const records = [];
  const browserCompatDataApis = Object.keys(_mdnBrowserCompatData.default.api);

  for (let i = 0; i < browserCompatDataApis.length; i += 1) {
    // ex. 'Window'
    const apiName = browserCompatDataApis[i]; // ex. Window {... }

    const apiObject = _mdnBrowserCompatData.default.api[apiName]; // ex. ['alert', 'document', ...]

    const apis = Object.keys(apiObject);
    records.push({
      apiType: 'js-api',
      type: 'js-api',
      protoChain: [(0, _MsApiCatalogProvider.interceptAndFormat)(apiName)],
      protoChainId: (0, _MsApiCatalogProvider.interceptAndFormat)(apiName)
    });

    for (let j = 0; j < apis.length; j += 1) {
      records.push({
        apiType: 'js-api',
        type: 'js-api',
        protoChain: [(0, _MsApiCatalogProvider.interceptAndFormat)(apiName), apis[j]],
        protoChainId: [(0, _MsApiCatalogProvider.interceptAndFormat)(apiName), apis[j]].join('.')
      });
    }
  }

  return records;
}