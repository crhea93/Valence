"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.interceptAndFormat = interceptAndFormat;
exports.camelCaseToHyphen = camelCaseToHyphen;
exports.default = MicrosoftAPICatalogProvider;

var _microsoftApiCatalogData = _interopRequireDefault(require("./microsoft-api-catalog-data.json"));

var _HasPrefix = _interopRequireDefault(require("../../helpers/HasPrefix"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Map webidl definition names to prototype chain parent
 * ex. Console -> console
 *
 * This helps generate protoChain's and protoChainId's
 * ex. Console.log -> console.log
 */
function interceptAndFormat(parentObjectId) {
  const APIsToLowercase = new Set(['Console', 'Window', 'Document', 'External', 'History', 'Location', 'Navigator', 'Performance', 'Screen', 'defaultStatus', 'Controllers']);
  return APIsToLowercase.has(parentObjectId) ? parentObjectId.toLowerCase() : parentObjectId;
}
/**
 * Comvert camelcase phrases to hypen-separated words
 * ex. camelCase => camel-case
 * This is used to map CSS DOM API names to css properties and attributes
 */


function camelCaseToHyphen(string) {
  return Array // Covert string to array
  .from(string) // If char `X` is uppercase, map it to `-x`
  .map(curr => curr === curr.toUpperCase() ? `-${curr.toLowerCase()}` : curr, []).join('');
}
/**
 * @TODO: Allow overriding database records
 */


function MicrosoftAPICatalogProvider() {
  const formattedRecords = [];
  const ignoredAPIs = ['arguments', 'caller', 'constructor', 'length', 'name', 'prototype']; // Convert two dimentional records to single dimentional array

  _microsoftApiCatalogData.default.forEach(record => {
    formattedRecords.push({ ...record,
      parentName: record.name,
      protoChain: [interceptAndFormat(record.name)],
      protoChainId: interceptAndFormat(record.name),
      spec: record.spec || false,
      webidlId: record.name
    });
    record.apis.forEach(api => // @TODO: Properly strip vendor prefixes and check if non-prefixed API
    //        exists. If not, create the record for it
    formattedRecords.push({ ...api,
      spec: record.spec || false,
      parentName: record.name
    }));
  });

  const JSAPIs = formattedRecords // Filter all CSS records. For some reason reason, MicrosoftAPICatalog does not report
  // the correctly. Validate that the record's name is a string. Some record
  // names are numbers from some odd reason
  .filter(fRecord => !fRecord.name.includes('-') && fRecord.parentName !== 'CSS2Properties' && Number.isNaN(parseInt(fRecord.name, 10)) && typeof fRecord.spec !== 'undefined').map(fRecord => ({
    id: fRecord.name,
    name: fRecord.name,
    specNames: fRecord.specNames,
    type: 'js-api',
    apiType: 'js-api',
    specIsFinished: fRecord.spec,
    protoChain: fRecord.protoChain || [interceptAndFormat(fRecord.parentName), fRecord.name]
  })) // Remove 'window' from the protochain
  .map(record => ({ ...record,
    protoChain: record.protoChain.filter(e => e !== 'window'),
    protoChainId: record.protoChain.filter(e => e !== 'window').join('.')
  })).filter(record => record.name !== 'defaultStatus' && record.protoChain.length !== 0 && !ignoredAPIs.includes(record.name) && !(0, _HasPrefix.default)(record.name) && !(0, _HasPrefix.default)(record.protoChainId) && !(0, _HasPrefix.default)(record.id)); // Find the CSS DOM API's and use them create the css style records
  // const CSSAPIs = JSAPIs
  //   .filter(record => record.protoChain.includes('CSSStyleDeclaration'))
  //   .map(record => ({
  //     ...record,
  //     id: camelCaseToHyphen(record.name),
  //     name: camelCaseToHyphen(record.name),
  //     type: 'css-api'
  //   }));
  // return [...CSSAPIs, ...JSAPIs];

  return JSAPIs;
}