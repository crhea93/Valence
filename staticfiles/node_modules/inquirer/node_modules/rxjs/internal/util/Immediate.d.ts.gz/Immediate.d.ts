export declare const Immediate: {
    setImmediate(cb: () => void): number;
    clearImmediate(handle: number): void;
};
