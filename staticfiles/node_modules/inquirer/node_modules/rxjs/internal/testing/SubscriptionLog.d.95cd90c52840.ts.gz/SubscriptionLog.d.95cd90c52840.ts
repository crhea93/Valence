export declare class SubscriptionLog {
    subscribedFrame: number;
    unsubscribedFrame: number;
    constructor(subscribedFrame: number, unsubscribedFrame?: number);
}
