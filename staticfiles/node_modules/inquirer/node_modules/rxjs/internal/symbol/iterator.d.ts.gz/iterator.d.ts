export declare function getSymbolIterator(): symbol;
export declare const iterator: symbol;
/**
 * @deprecated use {@link iterator} instead
 */
export declare const $$iterator: symbol;
