/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function isScheduler(value) {
    return value && typeof value.schedule === 'function';
}
//# sourceMappingURL=isScheduler.js.map
