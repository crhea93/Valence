/** PURE_IMPORTS_START _WebSocketSubject PURE_IMPORTS_END */
import { WebSocketSubject } from './WebSocketSubject';
export function webSocket(urlConfigOrSource) {
    return new WebSocketSubject(urlConfigOrSource);
}
//# sourceMappingURL=webSocket.js.map
