/** PURE_IMPORTS_START _mergeAll PURE_IMPORTS_END */
import { mergeAll } from './mergeAll';
export function concatAll() {
    return mergeAll(1);
}
//# sourceMappingURL=concatAll.js.map
