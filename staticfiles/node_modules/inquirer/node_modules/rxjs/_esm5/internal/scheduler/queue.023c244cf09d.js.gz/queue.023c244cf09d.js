/** PURE_IMPORTS_START _QueueAction,_QueueScheduler PURE_IMPORTS_END */
import { QueueAction } from './QueueAction';
import { QueueScheduler } from './QueueScheduler';
export var queue = /*@__PURE__*/ new QueueScheduler(QueueAction);
//# sourceMappingURL=queue.js.map
