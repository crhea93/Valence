/** PURE_IMPORTS_START _AsapAction,_AsapScheduler PURE_IMPORTS_END */
import { AsapAction } from './AsapAction';
import { AsapScheduler } from './AsapScheduler';
export var asap = /*@__PURE__*/ new AsapScheduler(AsapAction);
//# sourceMappingURL=asap.js.map
