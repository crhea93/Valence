/** PURE_IMPORTS_START _AnimationFrameAction,_AnimationFrameScheduler PURE_IMPORTS_END */
import { AnimationFrameAction } from './AnimationFrameAction';
import { AnimationFrameScheduler } from './AnimationFrameScheduler';
export var animationFrame = /*@__PURE__*/ new AnimationFrameScheduler(AnimationFrameAction);
//# sourceMappingURL=animationFrame.js.map
