/** PURE_IMPORTS_START _AsyncAction,_AsyncScheduler PURE_IMPORTS_END */
import { AsyncAction } from './AsyncAction';
import { AsyncScheduler } from './AsyncScheduler';
export var async = /*@__PURE__*/ new AsyncScheduler(AsyncAction);
//# sourceMappingURL=async.js.map
