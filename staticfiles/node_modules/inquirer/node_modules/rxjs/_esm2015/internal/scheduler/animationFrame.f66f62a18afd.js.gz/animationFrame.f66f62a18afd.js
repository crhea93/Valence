import { AnimationFrameAction } from './AnimationFrameAction';
import { AnimationFrameScheduler } from './AnimationFrameScheduler';
export const animationFrame = new AnimationFrameScheduler(AnimationFrameAction);
//# sourceMappingURL=animationFrame.js.map