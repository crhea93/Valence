"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var webSocket_1 = require("../internal/observable/dom/webSocket");
exports.webSocket = webSocket_1.webSocket;
var WebSocketSubject_1 = require("../internal/observable/dom/WebSocketSubject");
exports.WebSocketSubject = WebSocketSubject_1.WebSocketSubject;
//# sourceMappingURL=index.js.map