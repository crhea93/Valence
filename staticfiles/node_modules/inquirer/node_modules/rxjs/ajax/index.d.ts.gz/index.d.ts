export { ajax } from '../internal/observable/dom/ajax';
export { AjaxRequest, AjaxResponse, AjaxError, AjaxTimeoutError } from '../internal/observable/dom/AjaxObservable';
