"use strict";
var Observable_1 = require('../../Observable');
var sequenceEqual_1 = require('../../operator/sequenceEqual');
Observable_1.Observable.prototype.sequenceEqual = sequenceEqual_1.sequenceEqual;
//# sourceMappingURL=sequenceEqual.js.map