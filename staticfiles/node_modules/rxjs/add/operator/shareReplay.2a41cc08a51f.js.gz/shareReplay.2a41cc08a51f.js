"use strict";
var Observable_1 = require('../../Observable');
var shareReplay_1 = require('../../operator/shareReplay');
Observable_1.Observable.prototype.shareReplay = shareReplay_1.shareReplay;
//# sourceMappingURL=shareReplay.js.map