"use strict";
var Observable_1 = require('../../Observable');
var race_1 = require('../../observable/race');
Observable_1.Observable.race = race_1.race;
//# sourceMappingURL=race.js.map