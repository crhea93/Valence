import { Observable } from '../../Observable';
import { takeUntil } from '../../operator/takeUntil';
Observable.prototype.takeUntil = takeUntil;
//# sourceMappingURL=takeUntil.js.map