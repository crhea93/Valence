import { Observable } from '../../Observable';
import { last } from '../../operator/last';
Observable.prototype.last = last;
//# sourceMappingURL=last.js.map