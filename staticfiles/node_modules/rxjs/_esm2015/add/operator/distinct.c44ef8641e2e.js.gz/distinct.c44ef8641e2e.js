import { Observable } from '../../Observable';
import { distinct } from '../../operator/distinct';
Observable.prototype.distinct = distinct;
//# sourceMappingURL=distinct.js.map