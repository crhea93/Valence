import { Observable } from '../../Observable';
import { skipUntil } from '../../operator/skipUntil';
Observable.prototype.skipUntil = skipUntil;
//# sourceMappingURL=skipUntil.js.map