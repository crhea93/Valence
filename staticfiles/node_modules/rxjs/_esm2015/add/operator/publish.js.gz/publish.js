import { Observable } from '../../Observable';
import { publish } from '../../operator/publish';
Observable.prototype.publish = publish;
//# sourceMappingURL=publish.js.map