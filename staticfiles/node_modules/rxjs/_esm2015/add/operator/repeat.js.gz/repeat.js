import { Observable } from '../../Observable';
import { repeat } from '../../operator/repeat';
Observable.prototype.repeat = repeat;
//# sourceMappingURL=repeat.js.map