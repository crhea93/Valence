import { Observable } from '../../Observable';
import { sample } from '../../operator/sample';
Observable.prototype.sample = sample;
//# sourceMappingURL=sample.js.map