import { Observable } from '../../Observable';
import { first } from '../../operator/first';
Observable.prototype.first = first;
//# sourceMappingURL=first.js.map