import { Observable } from '../../Observable';
import { min } from '../../operator/min';
Observable.prototype.min = min;
//# sourceMappingURL=min.js.map