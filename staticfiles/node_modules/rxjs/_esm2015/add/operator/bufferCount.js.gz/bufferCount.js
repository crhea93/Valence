import { Observable } from '../../Observable';
import { bufferCount } from '../../operator/bufferCount';
Observable.prototype.bufferCount = bufferCount;
//# sourceMappingURL=bufferCount.js.map