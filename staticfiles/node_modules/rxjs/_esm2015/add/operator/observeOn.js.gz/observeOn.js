import { Observable } from '../../Observable';
import { observeOn } from '../../operator/observeOn';
Observable.prototype.observeOn = observeOn;
//# sourceMappingURL=observeOn.js.map