import { Observable } from '../../Observable';
import { reduce } from '../../operator/reduce';
Observable.prototype.reduce = reduce;
//# sourceMappingURL=reduce.js.map