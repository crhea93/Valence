import { Observable } from '../../Observable';
import { zipAll } from '../../operator/zipAll';
Observable.prototype.zipAll = zipAll;
//# sourceMappingURL=zipAll.js.map