import { Observable } from '../../Observable';
import { multicast } from '../../operator/multicast';
Observable.prototype.multicast = multicast;
//# sourceMappingURL=multicast.js.map