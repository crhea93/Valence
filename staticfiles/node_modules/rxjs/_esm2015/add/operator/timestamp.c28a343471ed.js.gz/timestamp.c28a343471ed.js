import { Observable } from '../../Observable';
import { timestamp } from '../../operator/timestamp';
Observable.prototype.timestamp = timestamp;
//# sourceMappingURL=timestamp.js.map