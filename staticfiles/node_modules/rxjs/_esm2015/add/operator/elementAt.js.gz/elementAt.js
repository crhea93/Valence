import { Observable } from '../../Observable';
import { elementAt } from '../../operator/elementAt';
Observable.prototype.elementAt = elementAt;
//# sourceMappingURL=elementAt.js.map