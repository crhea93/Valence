import { Observable } from '../../Observable';
import { filter } from '../../operator/filter';
Observable.prototype.filter = filter;
//# sourceMappingURL=filter.js.map