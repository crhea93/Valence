import { Observable } from '../../Observable';
import { every } from '../../operator/every';
Observable.prototype.every = every;
//# sourceMappingURL=every.js.map