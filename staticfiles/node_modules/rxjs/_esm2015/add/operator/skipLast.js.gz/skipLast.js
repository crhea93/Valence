import { Observable } from '../../Observable';
import { skipLast } from '../../operator/skipLast';
Observable.prototype.skipLast = skipLast;
//# sourceMappingURL=skipLast.js.map