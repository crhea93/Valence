import { Observable } from '../../Observable';
import { toArray } from '../../operator/toArray';
Observable.prototype.toArray = toArray;
//# sourceMappingURL=toArray.js.map