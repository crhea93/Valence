import { Observable } from '../../Observable';
import { mapTo } from '../../operator/mapTo';
Observable.prototype.mapTo = mapTo;
//# sourceMappingURL=mapTo.js.map