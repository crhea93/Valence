import { Observable } from '../../Observable';
import { max } from '../../operator/max';
Observable.prototype.max = max;
//# sourceMappingURL=max.js.map