import { Observable } from '../../Observable';
import { findIndex } from '../../operator/findIndex';
Observable.prototype.findIndex = findIndex;
//# sourceMappingURL=findIndex.js.map