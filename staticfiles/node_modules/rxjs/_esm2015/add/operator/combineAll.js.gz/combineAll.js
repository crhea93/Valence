import { Observable } from '../../Observable';
import { combineAll } from '../../operator/combineAll';
Observable.prototype.combineAll = combineAll;
//# sourceMappingURL=combineAll.js.map