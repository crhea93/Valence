import { Observable } from '../../Observable';
import { single } from '../../operator/single';
Observable.prototype.single = single;
//# sourceMappingURL=single.js.map