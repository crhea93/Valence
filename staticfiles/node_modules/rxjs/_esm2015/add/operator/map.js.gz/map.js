import { Observable } from '../../Observable';
import { map } from '../../operator/map';
Observable.prototype.map = map;
//# sourceMappingURL=map.js.map