import { Observable } from '../../Observable';
import { generate as staticGenerate } from '../../observable/generate';
Observable.generate = staticGenerate;
//# sourceMappingURL=generate.js.map