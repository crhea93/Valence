import { Observable } from '../../Observable';
import { _if } from '../../observable/if';
Observable.if = _if;
//# sourceMappingURL=if.js.map