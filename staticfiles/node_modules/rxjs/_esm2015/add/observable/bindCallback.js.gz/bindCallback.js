import { Observable } from '../../Observable';
import { bindCallback as staticBindCallback } from '../../observable/bindCallback';
Observable.bindCallback = staticBindCallback;
//# sourceMappingURL=bindCallback.js.map