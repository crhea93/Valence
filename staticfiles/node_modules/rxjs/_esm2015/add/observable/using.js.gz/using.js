import { Observable } from '../../Observable';
import { using as staticUsing } from '../../observable/using';
Observable.using = staticUsing;
//# sourceMappingURL=using.js.map