import { Observable } from '../../Observable';
import { fromEventPattern as staticFromEventPattern } from '../../observable/fromEventPattern';
Observable.fromEventPattern = staticFromEventPattern;
//# sourceMappingURL=fromEventPattern.js.map