import { Observable } from '../../Observable';
import { pairs as staticPairs } from '../../observable/pairs';
Observable.pairs = staticPairs;
//# sourceMappingURL=pairs.js.map