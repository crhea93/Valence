import { Observable } from '../../Observable';
import { range as staticRange } from '../../observable/range';
Observable.range = staticRange;
//# sourceMappingURL=range.js.map