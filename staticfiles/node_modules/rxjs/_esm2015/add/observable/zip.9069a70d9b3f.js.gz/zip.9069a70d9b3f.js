import { Observable } from '../../Observable';
import { zip as zipStatic } from '../../observable/zip';
Observable.zip = zipStatic;
//# sourceMappingURL=zip.js.map