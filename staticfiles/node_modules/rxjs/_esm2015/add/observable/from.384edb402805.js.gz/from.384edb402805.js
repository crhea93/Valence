import { Observable } from '../../Observable';
import { from as staticFrom } from '../../observable/from';
Observable.from = staticFrom;
//# sourceMappingURL=from.js.map