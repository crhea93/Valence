import { Observable } from '../../Observable';
import { _throw } from '../../observable/throw';
Observable.throw = _throw;
//# sourceMappingURL=throw.js.map