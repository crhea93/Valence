import { Observable } from '../../Observable';
import { onErrorResumeNext as staticOnErrorResumeNext } from '../../observable/onErrorResumeNext';
Observable.onErrorResumeNext = staticOnErrorResumeNext;
//# sourceMappingURL=onErrorResumeNext.js.map