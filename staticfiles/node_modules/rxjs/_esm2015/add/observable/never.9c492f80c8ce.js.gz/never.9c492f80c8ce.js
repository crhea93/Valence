import { Observable } from '../../Observable';
import { never as staticNever } from '../../observable/never';
Observable.never = staticNever;
//# sourceMappingURL=never.js.map