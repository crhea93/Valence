import { Observable } from '../../Observable';
import { forkJoin as staticForkJoin } from '../../observable/forkJoin';
Observable.forkJoin = staticForkJoin;
//# sourceMappingURL=forkJoin.js.map