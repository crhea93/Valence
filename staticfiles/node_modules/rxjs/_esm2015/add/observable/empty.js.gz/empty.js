import { Observable } from '../../Observable';
import { empty as staticEmpty } from '../../observable/empty';
Observable.empty = staticEmpty;
//# sourceMappingURL=empty.js.map