import { Observable } from '../../Observable';
import { fromPromise as staticFromPromise } from '../../observable/fromPromise';
Observable.fromPromise = staticFromPromise;
//# sourceMappingURL=fromPromise.js.map