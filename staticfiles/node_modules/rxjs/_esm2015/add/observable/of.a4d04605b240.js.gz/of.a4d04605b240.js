import { Observable } from '../../Observable';
import { of as staticOf } from '../../observable/of';
Observable.of = staticOf;
//# sourceMappingURL=of.js.map