import { Observable } from '../../Observable';
import { bindNodeCallback as staticBindNodeCallback } from '../../observable/bindNodeCallback';
Observable.bindNodeCallback = staticBindNodeCallback;
//# sourceMappingURL=bindNodeCallback.js.map