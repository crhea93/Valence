import { Observable } from '../../Observable';
import { interval as staticInterval } from '../../observable/interval';
Observable.interval = staticInterval;
//# sourceMappingURL=interval.js.map