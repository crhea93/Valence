import { Observable } from '../../Observable';
import { race as staticRace } from '../../observable/race';
Observable.race = staticRace;
//# sourceMappingURL=race.js.map