import { Observable } from '../../Observable';
import { concat as concatStatic } from '../../observable/concat';
Observable.concat = concatStatic;
//# sourceMappingURL=concat.js.map