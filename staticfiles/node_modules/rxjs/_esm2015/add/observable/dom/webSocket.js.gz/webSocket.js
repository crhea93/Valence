import { Observable } from '../../../Observable';
import { webSocket as staticWebSocket } from '../../../observable/dom/webSocket';
Observable.webSocket = staticWebSocket;
//# sourceMappingURL=webSocket.js.map