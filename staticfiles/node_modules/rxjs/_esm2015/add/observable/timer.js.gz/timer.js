import { Observable } from '../../Observable';
import { timer as staticTimer } from '../../observable/timer';
Observable.timer = staticTimer;
//# sourceMappingURL=timer.js.map