import { Observable } from '../Observable';
// HACK: this is here for backward compatability
// TODO(benlesh): remove this in v6.
export const toPromise = Observable.prototype.toPromise;
//# sourceMappingURL=toPromise.js.map