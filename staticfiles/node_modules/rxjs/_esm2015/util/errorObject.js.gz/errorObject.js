// typeof any so that it we don't have to cast when comparing a result to the error object
export const errorObject = { e: {} };
//# sourceMappingURL=errorObject.js.map