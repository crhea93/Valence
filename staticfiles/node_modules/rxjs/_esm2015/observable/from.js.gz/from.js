import { FromObservable } from './FromObservable';
export const from = FromObservable.create;
//# sourceMappingURL=from.js.map