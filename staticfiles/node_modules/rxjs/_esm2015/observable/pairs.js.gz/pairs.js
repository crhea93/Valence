import { PairsObservable } from './PairsObservable';
export const pairs = PairsObservable.create;
//# sourceMappingURL=pairs.js.map