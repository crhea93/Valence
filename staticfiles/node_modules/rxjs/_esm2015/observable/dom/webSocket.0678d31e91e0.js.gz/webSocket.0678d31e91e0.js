import { WebSocketSubject } from './WebSocketSubject';
export const webSocket = WebSocketSubject.create;
//# sourceMappingURL=webSocket.js.map