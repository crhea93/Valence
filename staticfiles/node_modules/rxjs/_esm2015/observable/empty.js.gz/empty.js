import { EmptyObservable } from './EmptyObservable';
export const empty = EmptyObservable.create;
//# sourceMappingURL=empty.js.map