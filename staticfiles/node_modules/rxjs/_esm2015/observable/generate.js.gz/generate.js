import { GenerateObservable } from './GenerateObservable';
export const generate = GenerateObservable.create;
//# sourceMappingURL=generate.js.map