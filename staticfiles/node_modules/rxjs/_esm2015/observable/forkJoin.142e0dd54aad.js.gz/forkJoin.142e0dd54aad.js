import { ForkJoinObservable } from './ForkJoinObservable';
export const forkJoin = ForkJoinObservable.create;
//# sourceMappingURL=forkJoin.js.map