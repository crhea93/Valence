import { ArrayObservable } from './ArrayObservable';
export const of = ArrayObservable.of;
//# sourceMappingURL=of.js.map