import { DeferObservable } from './DeferObservable';
export const defer = DeferObservable.create;
//# sourceMappingURL=defer.js.map