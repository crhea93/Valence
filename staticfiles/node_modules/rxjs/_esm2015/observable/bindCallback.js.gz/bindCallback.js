import { BoundCallbackObservable } from './BoundCallbackObservable';
export const bindCallback = BoundCallbackObservable.create;
//# sourceMappingURL=bindCallback.js.map