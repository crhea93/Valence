import { BoundCallbackObservable } from './BoundCallbackObservable';
export declare const bindCallback: typeof BoundCallbackObservable.create;
