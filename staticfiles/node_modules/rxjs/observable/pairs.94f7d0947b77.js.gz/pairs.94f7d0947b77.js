"use strict";
var PairsObservable_1 = require('./PairsObservable');
exports.pairs = PairsObservable_1.PairsObservable.create;
//# sourceMappingURL=pairs.js.map