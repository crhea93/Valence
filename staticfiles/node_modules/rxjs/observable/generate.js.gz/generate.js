"use strict";
var GenerateObservable_1 = require('./GenerateObservable');
exports.generate = GenerateObservable_1.GenerateObservable.create;
//# sourceMappingURL=generate.js.map