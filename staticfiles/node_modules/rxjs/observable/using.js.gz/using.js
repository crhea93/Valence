"use strict";
var UsingObservable_1 = require('./UsingObservable');
exports.using = UsingObservable_1.UsingObservable.create;
//# sourceMappingURL=using.js.map