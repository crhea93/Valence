import { RangeObservable } from './RangeObservable';
export declare const range: typeof RangeObservable.create;
