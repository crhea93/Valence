import { onErrorResumeNextStatic } from '../operators/onErrorResumeNext';
export declare const onErrorResumeNext: typeof onErrorResumeNextStatic;
