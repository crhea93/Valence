"use strict";
var onErrorResumeNext_1 = require('../operators/onErrorResumeNext');
exports.onErrorResumeNext = onErrorResumeNext_1.onErrorResumeNextStatic;
//# sourceMappingURL=onErrorResumeNext.js.map