"use strict";
var FromObservable_1 = require('./FromObservable');
exports.from = FromObservable_1.FromObservable.create;
//# sourceMappingURL=from.js.map