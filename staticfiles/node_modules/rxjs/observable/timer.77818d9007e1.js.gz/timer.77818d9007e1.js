"use strict";
var TimerObservable_1 = require('./TimerObservable');
exports.timer = TimerObservable_1.TimerObservable.create;
//# sourceMappingURL=timer.js.map