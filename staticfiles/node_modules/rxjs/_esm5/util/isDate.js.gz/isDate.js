/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function isDate(value) {
    return value instanceof Date && !isNaN(+value);
}
//# sourceMappingURL=isDate.js.map
