/** PURE_IMPORTS_START ._root,._MapPolyfill PURE_IMPORTS_END */
import { root } from './root';
import { MapPolyfill } from './MapPolyfill';
export var Map = root.Map || /*@__PURE__*/ (function () { return MapPolyfill; })();
//# sourceMappingURL=Map.js.map
