// typeof any so that it we don't have to cast when comparing a result to the error object
/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var errorObject = { e: {} };
//# sourceMappingURL=errorObject.js.map
