/** PURE_IMPORTS_START .._.._Observable,.._.._observable_defer PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { defer as staticDefer } from '../../observable/defer';
Observable.defer = staticDefer;
//# sourceMappingURL=defer.js.map
