/** PURE_IMPORTS_START .._.._Observable,.._.._observable_pairs PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { pairs as staticPairs } from '../../observable/pairs';
Observable.pairs = staticPairs;
//# sourceMappingURL=pairs.js.map
