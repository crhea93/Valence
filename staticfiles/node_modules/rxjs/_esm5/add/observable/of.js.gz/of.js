/** PURE_IMPORTS_START .._.._Observable,.._.._observable_of PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { of as staticOf } from '../../observable/of';
Observable.of = staticOf;
//# sourceMappingURL=of.js.map
