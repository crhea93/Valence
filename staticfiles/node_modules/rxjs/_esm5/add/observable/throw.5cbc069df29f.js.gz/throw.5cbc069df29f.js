/** PURE_IMPORTS_START .._.._Observable,.._.._observable_throw PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { _throw } from '../../observable/throw';
Observable.throw = _throw;
//# sourceMappingURL=throw.js.map
