/** PURE_IMPORTS_START .._.._Observable,.._.._observable_zip PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { zip as zipStatic } from '../../observable/zip';
Observable.zip = zipStatic;
//# sourceMappingURL=zip.js.map
