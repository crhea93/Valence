/** PURE_IMPORTS_START .._.._Observable,.._.._observable_bindNodeCallback PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { bindNodeCallback as staticBindNodeCallback } from '../../observable/bindNodeCallback';
Observable.bindNodeCallback = staticBindNodeCallback;
//# sourceMappingURL=bindNodeCallback.js.map
