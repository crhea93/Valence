/** PURE_IMPORTS_START .._.._Observable,.._.._observable_race PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { race as staticRace } from '../../observable/race';
Observable.race = staticRace;
//# sourceMappingURL=race.js.map
