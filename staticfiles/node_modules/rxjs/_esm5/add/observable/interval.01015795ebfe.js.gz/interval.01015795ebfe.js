/** PURE_IMPORTS_START .._.._Observable,.._.._observable_interval PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { interval as staticInterval } from '../../observable/interval';
Observable.interval = staticInterval;
//# sourceMappingURL=interval.js.map
