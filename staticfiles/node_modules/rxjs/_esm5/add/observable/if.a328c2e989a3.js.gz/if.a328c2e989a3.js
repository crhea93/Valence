/** PURE_IMPORTS_START .._.._Observable,.._.._observable_if PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { _if } from '../../observable/if';
Observable.if = _if;
//# sourceMappingURL=if.js.map
