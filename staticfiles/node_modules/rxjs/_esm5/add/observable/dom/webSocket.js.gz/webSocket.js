/** PURE_IMPORTS_START .._.._.._Observable,.._.._.._observable_dom_webSocket PURE_IMPORTS_END */
import { Observable } from '../../../Observable';
import { webSocket as staticWebSocket } from '../../../observable/dom/webSocket';
Observable.webSocket = staticWebSocket;
//# sourceMappingURL=webSocket.js.map
