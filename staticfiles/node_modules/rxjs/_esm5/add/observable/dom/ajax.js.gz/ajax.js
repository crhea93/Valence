/** PURE_IMPORTS_START .._.._.._Observable,.._.._.._observable_dom_ajax PURE_IMPORTS_END */
import { Observable } from '../../../Observable';
import { ajax as staticAjax } from '../../../observable/dom/ajax';
Observable.ajax = staticAjax;
//# sourceMappingURL=ajax.js.map
