/** PURE_IMPORTS_START .._.._Observable,.._.._observable_timer PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { timer as staticTimer } from '../../observable/timer';
Observable.timer = staticTimer;
//# sourceMappingURL=timer.js.map
