/** PURE_IMPORTS_START .._.._Observable,.._.._observable_concat PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { concat as concatStatic } from '../../observable/concat';
Observable.concat = concatStatic;
//# sourceMappingURL=concat.js.map
