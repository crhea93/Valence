/** PURE_IMPORTS_START .._.._Observable,.._.._observable_from PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { from as staticFrom } from '../../observable/from';
Observable.from = staticFrom;
//# sourceMappingURL=from.js.map
