/** PURE_IMPORTS_START .._.._Observable,.._.._observable_never PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { never as staticNever } from '../../observable/never';
Observable.never = staticNever;
//# sourceMappingURL=never.js.map
