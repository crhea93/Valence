/** PURE_IMPORTS_START .._.._Observable,.._.._observable_bindCallback PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { bindCallback as staticBindCallback } from '../../observable/bindCallback';
Observable.bindCallback = staticBindCallback;
//# sourceMappingURL=bindCallback.js.map
