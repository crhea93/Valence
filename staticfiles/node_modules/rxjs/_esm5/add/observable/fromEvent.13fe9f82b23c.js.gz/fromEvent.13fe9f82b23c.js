/** PURE_IMPORTS_START .._.._Observable,.._.._observable_fromEvent PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { fromEvent as staticFromEvent } from '../../observable/fromEvent';
Observable.fromEvent = staticFromEvent;
//# sourceMappingURL=fromEvent.js.map
