/** PURE_IMPORTS_START .._.._Observable,.._.._observable_forkJoin PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { forkJoin as staticForkJoin } from '../../observable/forkJoin';
Observable.forkJoin = staticForkJoin;
//# sourceMappingURL=forkJoin.js.map
