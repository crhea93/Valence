/** PURE_IMPORTS_START .._.._Observable,.._.._observable_merge PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { merge as mergeStatic } from '../../observable/merge';
Observable.merge = mergeStatic;
//# sourceMappingURL=merge.js.map
