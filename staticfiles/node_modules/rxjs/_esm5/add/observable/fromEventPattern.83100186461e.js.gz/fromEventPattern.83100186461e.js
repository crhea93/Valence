/** PURE_IMPORTS_START .._.._Observable,.._.._observable_fromEventPattern PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { fromEventPattern as staticFromEventPattern } from '../../observable/fromEventPattern';
Observable.fromEventPattern = staticFromEventPattern;
//# sourceMappingURL=fromEventPattern.js.map
