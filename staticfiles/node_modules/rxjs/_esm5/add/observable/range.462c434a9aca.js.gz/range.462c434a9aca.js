/** PURE_IMPORTS_START .._.._Observable,.._.._observable_range PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { range as staticRange } from '../../observable/range';
Observable.range = staticRange;
//# sourceMappingURL=range.js.map
