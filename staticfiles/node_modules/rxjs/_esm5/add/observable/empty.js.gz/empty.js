/** PURE_IMPORTS_START .._.._Observable,.._.._observable_empty PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { empty as staticEmpty } from '../../observable/empty';
Observable.empty = staticEmpty;
//# sourceMappingURL=empty.js.map
