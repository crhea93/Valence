/** PURE_IMPORTS_START .._.._Observable,.._.._observable_using PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { using as staticUsing } from '../../observable/using';
Observable.using = staticUsing;
//# sourceMappingURL=using.js.map
