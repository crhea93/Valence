/** PURE_IMPORTS_START .._.._Observable,.._.._observable_combineLatest PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { combineLatest as combineLatestStatic } from '../../observable/combineLatest';
Observable.combineLatest = combineLatestStatic;
//# sourceMappingURL=combineLatest.js.map
