/** PURE_IMPORTS_START .._.._Observable,.._.._observable_onErrorResumeNext PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { onErrorResumeNext as staticOnErrorResumeNext } from '../../observable/onErrorResumeNext';
Observable.onErrorResumeNext = staticOnErrorResumeNext;
//# sourceMappingURL=onErrorResumeNext.js.map
