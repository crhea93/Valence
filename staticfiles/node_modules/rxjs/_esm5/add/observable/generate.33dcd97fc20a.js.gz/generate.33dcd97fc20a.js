/** PURE_IMPORTS_START .._.._Observable,.._.._observable_generate PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { generate as staticGenerate } from '../../observable/generate';
Observable.generate = staticGenerate;
//# sourceMappingURL=generate.js.map
