/** PURE_IMPORTS_START .._.._Observable,.._.._operator_combineAll PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { combineAll } from '../../operator/combineAll';
Observable.prototype.combineAll = combineAll;
//# sourceMappingURL=combineAll.js.map
