/** PURE_IMPORTS_START .._.._Observable,.._.._operator_multicast PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { multicast } from '../../operator/multicast';
Observable.prototype.multicast = multicast;
//# sourceMappingURL=multicast.js.map
