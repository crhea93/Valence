/** PURE_IMPORTS_START .._.._Observable,.._.._operator_count PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { count } from '../../operator/count';
Observable.prototype.count = count;
//# sourceMappingURL=count.js.map
