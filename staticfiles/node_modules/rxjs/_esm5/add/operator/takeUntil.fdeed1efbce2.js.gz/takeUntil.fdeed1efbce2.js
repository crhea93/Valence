/** PURE_IMPORTS_START .._.._Observable,.._.._operator_takeUntil PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { takeUntil } from '../../operator/takeUntil';
Observable.prototype.takeUntil = takeUntil;
//# sourceMappingURL=takeUntil.js.map
