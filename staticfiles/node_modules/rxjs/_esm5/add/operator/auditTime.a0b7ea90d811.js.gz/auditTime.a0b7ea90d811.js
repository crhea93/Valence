/** PURE_IMPORTS_START .._.._Observable,.._.._operator_auditTime PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { auditTime } from '../../operator/auditTime';
Observable.prototype.auditTime = auditTime;
//# sourceMappingURL=auditTime.js.map
