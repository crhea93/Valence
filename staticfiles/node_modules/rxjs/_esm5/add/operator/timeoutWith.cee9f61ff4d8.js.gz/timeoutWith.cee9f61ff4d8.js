/** PURE_IMPORTS_START .._.._Observable,.._.._operator_timeoutWith PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { timeoutWith } from '../../operator/timeoutWith';
Observable.prototype.timeoutWith = timeoutWith;
//# sourceMappingURL=timeoutWith.js.map
