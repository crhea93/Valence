/** PURE_IMPORTS_START .._.._Observable,.._.._operator_zipAll PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { zipAll } from '../../operator/zipAll';
Observable.prototype.zipAll = zipAll;
//# sourceMappingURL=zipAll.js.map
