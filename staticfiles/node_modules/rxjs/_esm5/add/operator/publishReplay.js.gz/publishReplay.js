/** PURE_IMPORTS_START .._.._Observable,.._.._operator_publishReplay PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { publishReplay } from '../../operator/publishReplay';
Observable.prototype.publishReplay = publishReplay;
//# sourceMappingURL=publishReplay.js.map
