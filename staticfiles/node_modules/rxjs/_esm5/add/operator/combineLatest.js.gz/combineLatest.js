/** PURE_IMPORTS_START .._.._Observable,.._.._operator_combineLatest PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { combineLatest } from '../../operator/combineLatest';
Observable.prototype.combineLatest = combineLatest;
//# sourceMappingURL=combineLatest.js.map
