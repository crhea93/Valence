/** PURE_IMPORTS_START .._.._Observable,.._.._operator_toArray PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { toArray } from '../../operator/toArray';
Observable.prototype.toArray = toArray;
//# sourceMappingURL=toArray.js.map
