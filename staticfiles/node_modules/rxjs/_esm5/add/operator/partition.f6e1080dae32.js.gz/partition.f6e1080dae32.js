/** PURE_IMPORTS_START .._.._Observable,.._.._operator_partition PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { partition } from '../../operator/partition';
Observable.prototype.partition = partition;
//# sourceMappingURL=partition.js.map
