/** PURE_IMPORTS_START .._.._Observable,.._.._operator_timeInterval PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { timeInterval } from '../../operator/timeInterval';
Observable.prototype.timeInterval = timeInterval;
//# sourceMappingURL=timeInterval.js.map
