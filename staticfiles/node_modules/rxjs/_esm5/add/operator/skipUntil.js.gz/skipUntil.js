/** PURE_IMPORTS_START .._.._Observable,.._.._operator_skipUntil PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { skipUntil } from '../../operator/skipUntil';
Observable.prototype.skipUntil = skipUntil;
//# sourceMappingURL=skipUntil.js.map
