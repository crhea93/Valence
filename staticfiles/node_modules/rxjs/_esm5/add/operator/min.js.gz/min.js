/** PURE_IMPORTS_START .._.._Observable,.._.._operator_min PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { min } from '../../operator/min';
Observable.prototype.min = min;
//# sourceMappingURL=min.js.map
