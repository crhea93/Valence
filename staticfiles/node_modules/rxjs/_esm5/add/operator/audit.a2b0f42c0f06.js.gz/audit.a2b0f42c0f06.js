/** PURE_IMPORTS_START .._.._Observable,.._.._operator_audit PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { audit } from '../../operator/audit';
Observable.prototype.audit = audit;
//# sourceMappingURL=audit.js.map
