/** PURE_IMPORTS_START .._.._Observable,.._.._operator_single PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { single } from '../../operator/single';
Observable.prototype.single = single;
//# sourceMappingURL=single.js.map
