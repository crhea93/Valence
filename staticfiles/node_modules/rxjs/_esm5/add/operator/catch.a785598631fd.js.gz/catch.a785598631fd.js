/** PURE_IMPORTS_START .._.._Observable,.._.._operator_catch PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { _catch } from '../../operator/catch';
Observable.prototype.catch = _catch;
Observable.prototype._catch = _catch;
//# sourceMappingURL=catch.js.map
