/** PURE_IMPORTS_START .._.._Observable,.._.._operator_defaultIfEmpty PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { defaultIfEmpty } from '../../operator/defaultIfEmpty';
Observable.prototype.defaultIfEmpty = defaultIfEmpty;
//# sourceMappingURL=defaultIfEmpty.js.map
