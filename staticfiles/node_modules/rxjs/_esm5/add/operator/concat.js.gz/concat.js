/** PURE_IMPORTS_START .._.._Observable,.._.._operator_concat PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { concat } from '../../operator/concat';
Observable.prototype.concat = concat;
//# sourceMappingURL=concat.js.map
