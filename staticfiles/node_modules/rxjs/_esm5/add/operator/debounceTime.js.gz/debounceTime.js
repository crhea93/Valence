/** PURE_IMPORTS_START .._.._Observable,.._.._operator_debounceTime PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { debounceTime } from '../../operator/debounceTime';
Observable.prototype.debounceTime = debounceTime;
//# sourceMappingURL=debounceTime.js.map
