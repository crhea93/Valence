/** PURE_IMPORTS_START .._.._Observable,.._.._operator_let PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { letProto } from '../../operator/let';
Observable.prototype.let = letProto;
Observable.prototype.letBind = letProto;
//# sourceMappingURL=let.js.map
