/** PURE_IMPORTS_START .._.._Observable,.._.._operator_switch PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { _switch } from '../../operator/switch';
Observable.prototype.switch = _switch;
Observable.prototype._switch = _switch;
//# sourceMappingURL=switch.js.map
