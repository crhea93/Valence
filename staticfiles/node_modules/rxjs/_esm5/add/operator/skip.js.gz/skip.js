/** PURE_IMPORTS_START .._.._Observable,.._.._operator_skip PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { skip } from '../../operator/skip';
Observable.prototype.skip = skip;
//# sourceMappingURL=skip.js.map
