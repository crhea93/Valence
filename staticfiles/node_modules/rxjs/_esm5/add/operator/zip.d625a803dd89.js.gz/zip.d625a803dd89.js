/** PURE_IMPORTS_START .._.._Observable,.._.._operator_zip PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { zipProto } from '../../operator/zip';
Observable.prototype.zip = zipProto;
//# sourceMappingURL=zip.js.map
