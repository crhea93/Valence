/** PURE_IMPORTS_START .._.._Observable,.._.._operator_sample PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { sample } from '../../operator/sample';
Observable.prototype.sample = sample;
//# sourceMappingURL=sample.js.map
