/** PURE_IMPORTS_START .._.._Observable,.._.._operator_distinct PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { distinct } from '../../operator/distinct';
Observable.prototype.distinct = distinct;
//# sourceMappingURL=distinct.js.map
