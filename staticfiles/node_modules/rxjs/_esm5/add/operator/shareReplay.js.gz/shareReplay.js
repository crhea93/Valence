/** PURE_IMPORTS_START .._.._Observable,.._.._operator_shareReplay PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { shareReplay } from '../../operator/shareReplay';
Observable.prototype.shareReplay = shareReplay;
//# sourceMappingURL=shareReplay.js.map
