/** PURE_IMPORTS_START .._.._Observable,.._.._operator_mergeScan PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { mergeScan } from '../../operator/mergeScan';
Observable.prototype.mergeScan = mergeScan;
//# sourceMappingURL=mergeScan.js.map
