/** PURE_IMPORTS_START .._.._Observable,.._.._operator_sequenceEqual PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { sequenceEqual } from '../../operator/sequenceEqual';
Observable.prototype.sequenceEqual = sequenceEqual;
//# sourceMappingURL=sequenceEqual.js.map
