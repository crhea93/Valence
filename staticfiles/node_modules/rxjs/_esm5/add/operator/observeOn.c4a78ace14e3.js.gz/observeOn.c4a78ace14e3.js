/** PURE_IMPORTS_START .._.._Observable,.._.._operator_observeOn PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { observeOn } from '../../operator/observeOn';
Observable.prototype.observeOn = observeOn;
//# sourceMappingURL=observeOn.js.map
