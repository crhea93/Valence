/** PURE_IMPORTS_START .._.._Observable,.._.._operator_windowCount PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { windowCount } from '../../operator/windowCount';
Observable.prototype.windowCount = windowCount;
//# sourceMappingURL=windowCount.js.map
