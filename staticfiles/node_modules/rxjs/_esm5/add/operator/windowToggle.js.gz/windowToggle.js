/** PURE_IMPORTS_START .._.._Observable,.._.._operator_windowToggle PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { windowToggle } from '../../operator/windowToggle';
Observable.prototype.windowToggle = windowToggle;
//# sourceMappingURL=windowToggle.js.map
