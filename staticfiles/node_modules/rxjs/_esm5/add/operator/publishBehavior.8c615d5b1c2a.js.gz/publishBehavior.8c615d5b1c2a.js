/** PURE_IMPORTS_START .._.._Observable,.._.._operator_publishBehavior PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { publishBehavior } from '../../operator/publishBehavior';
Observable.prototype.publishBehavior = publishBehavior;
//# sourceMappingURL=publishBehavior.js.map
