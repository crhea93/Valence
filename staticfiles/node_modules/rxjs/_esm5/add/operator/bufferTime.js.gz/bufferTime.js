/** PURE_IMPORTS_START .._.._Observable,.._.._operator_bufferTime PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { bufferTime } from '../../operator/bufferTime';
Observable.prototype.bufferTime = bufferTime;
//# sourceMappingURL=bufferTime.js.map
