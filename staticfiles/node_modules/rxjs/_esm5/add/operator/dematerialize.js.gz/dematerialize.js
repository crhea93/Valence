/** PURE_IMPORTS_START .._.._Observable,.._.._operator_dematerialize PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { dematerialize } from '../../operator/dematerialize';
Observable.prototype.dematerialize = dematerialize;
//# sourceMappingURL=dematerialize.js.map
