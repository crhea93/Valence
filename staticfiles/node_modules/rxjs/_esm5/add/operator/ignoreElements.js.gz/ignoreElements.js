/** PURE_IMPORTS_START .._.._Observable,.._.._operator_ignoreElements PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { ignoreElements } from '../../operator/ignoreElements';
Observable.prototype.ignoreElements = ignoreElements;
//# sourceMappingURL=ignoreElements.js.map
