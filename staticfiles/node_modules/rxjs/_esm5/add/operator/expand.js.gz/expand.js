/** PURE_IMPORTS_START .._.._Observable,.._.._operator_expand PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { expand } from '../../operator/expand';
Observable.prototype.expand = expand;
//# sourceMappingURL=expand.js.map
