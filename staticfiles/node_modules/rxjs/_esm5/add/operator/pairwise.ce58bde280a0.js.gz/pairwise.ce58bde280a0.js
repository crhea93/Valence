/** PURE_IMPORTS_START .._.._Observable,.._.._operator_pairwise PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { pairwise } from '../../operator/pairwise';
Observable.prototype.pairwise = pairwise;
//# sourceMappingURL=pairwise.js.map
