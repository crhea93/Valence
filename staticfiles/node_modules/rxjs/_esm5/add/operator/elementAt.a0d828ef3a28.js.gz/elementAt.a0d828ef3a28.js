/** PURE_IMPORTS_START .._.._Observable,.._.._operator_elementAt PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { elementAt } from '../../operator/elementAt';
Observable.prototype.elementAt = elementAt;
//# sourceMappingURL=elementAt.js.map
