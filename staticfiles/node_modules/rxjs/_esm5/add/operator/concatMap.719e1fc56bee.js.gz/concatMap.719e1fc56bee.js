/** PURE_IMPORTS_START .._.._Observable,.._.._operator_concatMap PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { concatMap } from '../../operator/concatMap';
Observable.prototype.concatMap = concatMap;
//# sourceMappingURL=concatMap.js.map
