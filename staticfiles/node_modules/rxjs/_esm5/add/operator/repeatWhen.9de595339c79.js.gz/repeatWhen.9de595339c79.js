/** PURE_IMPORTS_START .._.._Observable,.._.._operator_repeatWhen PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { repeatWhen } from '../../operator/repeatWhen';
Observable.prototype.repeatWhen = repeatWhen;
//# sourceMappingURL=repeatWhen.js.map
