/** PURE_IMPORTS_START .._.._Observable,.._.._operator_windowTime PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { windowTime } from '../../operator/windowTime';
Observable.prototype.windowTime = windowTime;
//# sourceMappingURL=windowTime.js.map
