/** PURE_IMPORTS_START .._.._Observable,.._.._operator_switchMapTo PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { switchMapTo } from '../../operator/switchMapTo';
Observable.prototype.switchMapTo = switchMapTo;
//# sourceMappingURL=switchMapTo.js.map
