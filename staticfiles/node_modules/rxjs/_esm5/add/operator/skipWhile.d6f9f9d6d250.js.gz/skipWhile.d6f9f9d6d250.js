/** PURE_IMPORTS_START .._.._Observable,.._.._operator_skipWhile PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { skipWhile } from '../../operator/skipWhile';
Observable.prototype.skipWhile = skipWhile;
//# sourceMappingURL=skipWhile.js.map
