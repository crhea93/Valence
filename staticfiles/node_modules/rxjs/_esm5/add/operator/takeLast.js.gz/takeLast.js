/** PURE_IMPORTS_START .._.._Observable,.._.._operator_takeLast PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { takeLast } from '../../operator/takeLast';
Observable.prototype.takeLast = takeLast;
//# sourceMappingURL=takeLast.js.map
