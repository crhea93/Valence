/** PURE_IMPORTS_START .._.._Observable,.._.._operator_throttle PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { throttle } from '../../operator/throttle';
Observable.prototype.throttle = throttle;
//# sourceMappingURL=throttle.js.map
