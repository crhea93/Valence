/** PURE_IMPORTS_START .._.._Observable,.._.._operator_withLatestFrom PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { withLatestFrom } from '../../operator/withLatestFrom';
Observable.prototype.withLatestFrom = withLatestFrom;
//# sourceMappingURL=withLatestFrom.js.map
