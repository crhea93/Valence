/** PURE_IMPORTS_START .._.._Observable,.._.._operator_bufferToggle PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { bufferToggle } from '../../operator/bufferToggle';
Observable.prototype.bufferToggle = bufferToggle;
//# sourceMappingURL=bufferToggle.js.map
