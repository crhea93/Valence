/** PURE_IMPORTS_START .._.._Observable,.._.._operator_distinctUntilChanged PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { distinctUntilChanged } from '../../operator/distinctUntilChanged';
Observable.prototype.distinctUntilChanged = distinctUntilChanged;
//# sourceMappingURL=distinctUntilChanged.js.map
