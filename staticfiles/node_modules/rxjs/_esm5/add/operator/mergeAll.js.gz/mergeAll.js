/** PURE_IMPORTS_START .._.._Observable,.._.._operator_mergeAll PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { mergeAll } from '../../operator/mergeAll';
Observable.prototype.mergeAll = mergeAll;
//# sourceMappingURL=mergeAll.js.map
