/** PURE_IMPORTS_START .._.._Observable,.._.._operator_timeout PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { timeout } from '../../operator/timeout';
Observable.prototype.timeout = timeout;
//# sourceMappingURL=timeout.js.map
