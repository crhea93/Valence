/** PURE_IMPORTS_START .._.._Observable,.._.._operator_publishLast PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { publishLast } from '../../operator/publishLast';
Observable.prototype.publishLast = publishLast;
//# sourceMappingURL=publishLast.js.map
