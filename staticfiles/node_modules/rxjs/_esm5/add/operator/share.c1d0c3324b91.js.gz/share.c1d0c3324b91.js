/** PURE_IMPORTS_START .._.._Observable,.._.._operator_share PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { share } from '../../operator/share';
Observable.prototype.share = share;
//# sourceMappingURL=share.js.map
