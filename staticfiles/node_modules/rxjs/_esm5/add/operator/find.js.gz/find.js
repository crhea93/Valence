/** PURE_IMPORTS_START .._.._Observable,.._.._operator_find PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { find } from '../../operator/find';
Observable.prototype.find = find;
//# sourceMappingURL=find.js.map
