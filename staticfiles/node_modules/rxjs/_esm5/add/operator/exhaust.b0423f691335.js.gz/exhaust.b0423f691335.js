/** PURE_IMPORTS_START .._.._Observable,.._.._operator_exhaust PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { exhaust } from '../../operator/exhaust';
Observable.prototype.exhaust = exhaust;
//# sourceMappingURL=exhaust.js.map
