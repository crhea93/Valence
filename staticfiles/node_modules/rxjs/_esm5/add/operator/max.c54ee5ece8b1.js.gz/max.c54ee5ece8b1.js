/** PURE_IMPORTS_START .._.._Observable,.._.._operator_max PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { max } from '../../operator/max';
Observable.prototype.max = max;
//# sourceMappingURL=max.js.map
