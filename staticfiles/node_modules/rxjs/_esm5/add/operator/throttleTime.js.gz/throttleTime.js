/** PURE_IMPORTS_START .._.._Observable,.._.._operator_throttleTime PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { throttleTime } from '../../operator/throttleTime';
Observable.prototype.throttleTime = throttleTime;
//# sourceMappingURL=throttleTime.js.map
