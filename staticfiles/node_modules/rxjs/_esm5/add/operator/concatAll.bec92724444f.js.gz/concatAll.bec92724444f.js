/** PURE_IMPORTS_START .._.._Observable,.._.._operator_concatAll PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { concatAll } from '../../operator/concatAll';
Observable.prototype.concatAll = concatAll;
//# sourceMappingURL=concatAll.js.map
