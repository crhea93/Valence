/** PURE_IMPORTS_START .._.._Observable,.._.._operator_first PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { first } from '../../operator/first';
Observable.prototype.first = first;
//# sourceMappingURL=first.js.map
