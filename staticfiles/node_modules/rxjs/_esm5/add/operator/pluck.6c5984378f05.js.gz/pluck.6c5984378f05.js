/** PURE_IMPORTS_START .._.._Observable,.._.._operator_pluck PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { pluck } from '../../operator/pluck';
Observable.prototype.pluck = pluck;
//# sourceMappingURL=pluck.js.map
