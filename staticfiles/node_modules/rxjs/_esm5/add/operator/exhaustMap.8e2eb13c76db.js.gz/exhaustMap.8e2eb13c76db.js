/** PURE_IMPORTS_START .._.._Observable,.._.._operator_exhaustMap PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { exhaustMap } from '../../operator/exhaustMap';
Observable.prototype.exhaustMap = exhaustMap;
//# sourceMappingURL=exhaustMap.js.map
