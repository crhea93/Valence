/** PURE_IMPORTS_START .._.._Observable,.._.._operator_skipLast PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { skipLast } from '../../operator/skipLast';
Observable.prototype.skipLast = skipLast;
//# sourceMappingURL=skipLast.js.map
