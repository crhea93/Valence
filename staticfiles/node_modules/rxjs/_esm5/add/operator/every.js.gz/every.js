/** PURE_IMPORTS_START .._.._Observable,.._.._operator_every PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { every } from '../../operator/every';
Observable.prototype.every = every;
//# sourceMappingURL=every.js.map
