/** PURE_IMPORTS_START .._.._Observable,.._.._operator_concatMapTo PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { concatMapTo } from '../../operator/concatMapTo';
Observable.prototype.concatMapTo = concatMapTo;
//# sourceMappingURL=concatMapTo.js.map
