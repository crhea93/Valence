/** PURE_IMPORTS_START .._.._Observable,.._.._operator_map PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { map } from '../../operator/map';
Observable.prototype.map = map;
//# sourceMappingURL=map.js.map
