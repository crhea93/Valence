/** PURE_IMPORTS_START .._.._Observable,.._.._operator_mapTo PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { mapTo } from '../../operator/mapTo';
Observable.prototype.mapTo = mapTo;
//# sourceMappingURL=mapTo.js.map
