/** PURE_IMPORTS_START .._.._Observable,.._.._operator_bufferCount PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { bufferCount } from '../../operator/bufferCount';
Observable.prototype.bufferCount = bufferCount;
//# sourceMappingURL=bufferCount.js.map
