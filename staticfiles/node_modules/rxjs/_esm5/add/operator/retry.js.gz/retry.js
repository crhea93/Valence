/** PURE_IMPORTS_START .._.._Observable,.._.._operator_retry PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { retry } from '../../operator/retry';
Observable.prototype.retry = retry;
//# sourceMappingURL=retry.js.map
