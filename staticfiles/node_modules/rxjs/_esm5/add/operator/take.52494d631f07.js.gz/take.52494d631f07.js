/** PURE_IMPORTS_START .._.._Observable,.._.._operator_take PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { take } from '../../operator/take';
Observable.prototype.take = take;
//# sourceMappingURL=take.js.map
