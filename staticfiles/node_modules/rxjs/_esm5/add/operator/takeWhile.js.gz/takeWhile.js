/** PURE_IMPORTS_START .._.._Observable,.._.._operator_takeWhile PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { takeWhile } from '../../operator/takeWhile';
Observable.prototype.takeWhile = takeWhile;
//# sourceMappingURL=takeWhile.js.map
