/** PURE_IMPORTS_START .._.._Observable,.._.._operator_isEmpty PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { isEmpty } from '../../operator/isEmpty';
Observable.prototype.isEmpty = isEmpty;
//# sourceMappingURL=isEmpty.js.map
