/** PURE_IMPORTS_START .._.._Observable,.._.._operator_switchMap PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { switchMap } from '../../operator/switchMap';
Observable.prototype.switchMap = switchMap;
//# sourceMappingURL=switchMap.js.map
