/** PURE_IMPORTS_START .._.._Observable,.._.._operator_reduce PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { reduce } from '../../operator/reduce';
Observable.prototype.reduce = reduce;
//# sourceMappingURL=reduce.js.map
