/** PURE_IMPORTS_START .._.._Observable,.._.._operator_timestamp PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { timestamp } from '../../operator/timestamp';
Observable.prototype.timestamp = timestamp;
//# sourceMappingURL=timestamp.js.map
