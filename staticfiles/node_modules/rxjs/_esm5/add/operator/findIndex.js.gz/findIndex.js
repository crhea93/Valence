/** PURE_IMPORTS_START .._.._Observable,.._.._operator_findIndex PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { findIndex } from '../../operator/findIndex';
Observable.prototype.findIndex = findIndex;
//# sourceMappingURL=findIndex.js.map
