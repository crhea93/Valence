/** PURE_IMPORTS_START .._.._Observable,.._.._operator_retryWhen PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { retryWhen } from '../../operator/retryWhen';
Observable.prototype.retryWhen = retryWhen;
//# sourceMappingURL=retryWhen.js.map
