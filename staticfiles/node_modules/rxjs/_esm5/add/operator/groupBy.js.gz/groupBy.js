/** PURE_IMPORTS_START .._.._Observable,.._.._operator_groupBy PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { groupBy } from '../../operator/groupBy';
Observable.prototype.groupBy = groupBy;
//# sourceMappingURL=groupBy.js.map
