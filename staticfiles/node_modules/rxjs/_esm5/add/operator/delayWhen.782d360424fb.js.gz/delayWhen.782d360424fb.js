/** PURE_IMPORTS_START .._.._Observable,.._.._operator_delayWhen PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { delayWhen } from '../../operator/delayWhen';
Observable.prototype.delayWhen = delayWhen;
//# sourceMappingURL=delayWhen.js.map
