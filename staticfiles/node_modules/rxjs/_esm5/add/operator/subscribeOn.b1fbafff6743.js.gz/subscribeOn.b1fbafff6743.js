/** PURE_IMPORTS_START .._.._Observable,.._.._operator_subscribeOn PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { subscribeOn } from '../../operator/subscribeOn';
Observable.prototype.subscribeOn = subscribeOn;
//# sourceMappingURL=subscribeOn.js.map
