/** PURE_IMPORTS_START .._.._Observable,.._.._operator_publish PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { publish } from '../../operator/publish';
Observable.prototype.publish = publish;
//# sourceMappingURL=publish.js.map
