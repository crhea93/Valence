/** PURE_IMPORTS_START .._.._Observable,.._.._operator_race PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { race } from '../../operator/race';
Observable.prototype.race = race;
//# sourceMappingURL=race.js.map
