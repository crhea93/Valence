/** PURE_IMPORTS_START .._.._Observable,.._.._operator_last PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { last } from '../../operator/last';
Observable.prototype.last = last;
//# sourceMappingURL=last.js.map
