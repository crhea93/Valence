/** PURE_IMPORTS_START .._.._Observable,.._.._operator_debounce PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { debounce } from '../../operator/debounce';
Observable.prototype.debounce = debounce;
//# sourceMappingURL=debounce.js.map
