/** PURE_IMPORTS_START .._.._Observable,.._.._operator_delay PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { delay } from '../../operator/delay';
Observable.prototype.delay = delay;
//# sourceMappingURL=delay.js.map
