/** PURE_IMPORTS_START .._.._Observable,.._.._operator_windowWhen PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { windowWhen } from '../../operator/windowWhen';
Observable.prototype.windowWhen = windowWhen;
//# sourceMappingURL=windowWhen.js.map
