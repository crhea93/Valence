/** PURE_IMPORTS_START .._.._Observable,.._.._operator_filter PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { filter } from '../../operator/filter';
Observable.prototype.filter = filter;
//# sourceMappingURL=filter.js.map
