/** PURE_IMPORTS_START .._.._Observable,.._.._operator_bufferWhen PURE_IMPORTS_END */
import { Observable } from '../../Observable';
import { bufferWhen } from '../../operator/bufferWhen';
Observable.prototype.bufferWhen = bufferWhen;
//# sourceMappingURL=bufferWhen.js.map
