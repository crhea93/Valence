/**
 * @param func
 * @return {Observable<R>}
 * @method let
 * @owner Observable
 */
/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function letProto(func) {
    return func(this);
}
//# sourceMappingURL=let.js.map
