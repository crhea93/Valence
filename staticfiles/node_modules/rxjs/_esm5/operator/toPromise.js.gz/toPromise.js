/** PURE_IMPORTS_START .._Observable PURE_IMPORTS_END */
import { Observable } from '../Observable';
// HACK: this is here for backward compatability
// TODO(benlesh): remove this in v6.
export var toPromise = Observable.prototype.toPromise;
//# sourceMappingURL=toPromise.js.map
