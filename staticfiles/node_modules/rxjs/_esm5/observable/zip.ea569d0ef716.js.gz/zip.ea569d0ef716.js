/** PURE_IMPORTS_START .._operators_zip PURE_IMPORTS_END */
import { zipStatic } from '../operators/zip';
export var zip = zipStatic;
//# sourceMappingURL=zip.js.map
