/** PURE_IMPORTS_START ._EmptyObservable PURE_IMPORTS_END */
import { EmptyObservable } from './EmptyObservable';
export var empty = EmptyObservable.create;
//# sourceMappingURL=empty.js.map
