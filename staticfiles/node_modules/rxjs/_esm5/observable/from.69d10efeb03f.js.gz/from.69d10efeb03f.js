/** PURE_IMPORTS_START ._FromObservable PURE_IMPORTS_END */
import { FromObservable } from './FromObservable';
export var from = FromObservable.create;
//# sourceMappingURL=from.js.map
