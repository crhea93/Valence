/** PURE_IMPORTS_START ._GenerateObservable PURE_IMPORTS_END */
import { GenerateObservable } from './GenerateObservable';
export var generate = GenerateObservable.create;
//# sourceMappingURL=generate.js.map
