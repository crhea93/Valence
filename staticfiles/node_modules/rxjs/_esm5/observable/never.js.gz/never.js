/** PURE_IMPORTS_START ._NeverObservable PURE_IMPORTS_END */
import { NeverObservable } from './NeverObservable';
export var never = NeverObservable.create;
//# sourceMappingURL=never.js.map
