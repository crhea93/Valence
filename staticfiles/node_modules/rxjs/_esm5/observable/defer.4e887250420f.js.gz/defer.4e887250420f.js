/** PURE_IMPORTS_START ._DeferObservable PURE_IMPORTS_END */
import { DeferObservable } from './DeferObservable';
export var defer = DeferObservable.create;
//# sourceMappingURL=defer.js.map
