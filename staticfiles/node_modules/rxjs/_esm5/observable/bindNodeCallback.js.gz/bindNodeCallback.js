/** PURE_IMPORTS_START ._BoundNodeCallbackObservable PURE_IMPORTS_END */
import { BoundNodeCallbackObservable } from './BoundNodeCallbackObservable';
export var bindNodeCallback = BoundNodeCallbackObservable.create;
//# sourceMappingURL=bindNodeCallback.js.map
