/** PURE_IMPORTS_START ._ForkJoinObservable PURE_IMPORTS_END */
import { ForkJoinObservable } from './ForkJoinObservable';
export var forkJoin = ForkJoinObservable.create;
//# sourceMappingURL=forkJoin.js.map
