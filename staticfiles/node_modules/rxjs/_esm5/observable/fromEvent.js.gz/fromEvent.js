/** PURE_IMPORTS_START ._FromEventObservable PURE_IMPORTS_END */
import { FromEventObservable } from './FromEventObservable';
export var fromEvent = FromEventObservable.create;
//# sourceMappingURL=fromEvent.js.map
