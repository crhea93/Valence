/** PURE_IMPORTS_START ._PromiseObservable PURE_IMPORTS_END */
import { PromiseObservable } from './PromiseObservable';
export var fromPromise = PromiseObservable.create;
//# sourceMappingURL=fromPromise.js.map
