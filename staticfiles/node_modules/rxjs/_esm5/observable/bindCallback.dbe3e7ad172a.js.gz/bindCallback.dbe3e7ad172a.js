/** PURE_IMPORTS_START ._BoundCallbackObservable PURE_IMPORTS_END */
import { BoundCallbackObservable } from './BoundCallbackObservable';
export var bindCallback = BoundCallbackObservable.create;
//# sourceMappingURL=bindCallback.js.map
