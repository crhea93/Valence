/** PURE_IMPORTS_START .._operators_onErrorResumeNext PURE_IMPORTS_END */
import { onErrorResumeNextStatic } from '../operators/onErrorResumeNext';
export var onErrorResumeNext = onErrorResumeNextStatic;
//# sourceMappingURL=onErrorResumeNext.js.map
