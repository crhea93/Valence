/** PURE_IMPORTS_START ._UsingObservable PURE_IMPORTS_END */
import { UsingObservable } from './UsingObservable';
export var using = UsingObservable.create;
//# sourceMappingURL=using.js.map
