/** PURE_IMPORTS_START ._WebSocketSubject PURE_IMPORTS_END */
import { WebSocketSubject } from './WebSocketSubject';
export var webSocket = WebSocketSubject.create;
//# sourceMappingURL=webSocket.js.map
