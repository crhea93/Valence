/** PURE_IMPORTS_START ._FromEventPatternObservable PURE_IMPORTS_END */
import { FromEventPatternObservable } from './FromEventPatternObservable';
export var fromEventPattern = FromEventPatternObservable.create;
//# sourceMappingURL=fromEventPattern.js.map
