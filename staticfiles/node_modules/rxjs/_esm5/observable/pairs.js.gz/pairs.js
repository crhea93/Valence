/** PURE_IMPORTS_START ._PairsObservable PURE_IMPORTS_END */
import { PairsObservable } from './PairsObservable';
export var pairs = PairsObservable.create;
//# sourceMappingURL=pairs.js.map
