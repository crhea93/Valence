/** PURE_IMPORTS_START ._ErrorObservable PURE_IMPORTS_END */
import { ErrorObservable } from './ErrorObservable';
export var _throw = ErrorObservable.create;
//# sourceMappingURL=throw.js.map
