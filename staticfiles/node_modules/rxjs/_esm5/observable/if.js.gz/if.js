/** PURE_IMPORTS_START ._IfObservable PURE_IMPORTS_END */
import { IfObservable } from './IfObservable';
export var _if = IfObservable.create;
//# sourceMappingURL=if.js.map
