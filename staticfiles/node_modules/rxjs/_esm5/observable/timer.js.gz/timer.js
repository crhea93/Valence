/** PURE_IMPORTS_START ._TimerObservable PURE_IMPORTS_END */
import { TimerObservable } from './TimerObservable';
export var timer = TimerObservable.create;
//# sourceMappingURL=timer.js.map
