/** PURE_IMPORTS_START ._IntervalObservable PURE_IMPORTS_END */
import { IntervalObservable } from './IntervalObservable';
export var interval = IntervalObservable.create;
//# sourceMappingURL=interval.js.map
