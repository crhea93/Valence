/** PURE_IMPORTS_START ._RangeObservable PURE_IMPORTS_END */
import { RangeObservable } from './RangeObservable';
export var range = RangeObservable.create;
//# sourceMappingURL=range.js.map
