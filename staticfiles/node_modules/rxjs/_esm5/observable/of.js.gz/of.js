/** PURE_IMPORTS_START ._ArrayObservable PURE_IMPORTS_END */
import { ArrayObservable } from './ArrayObservable';
export var of = ArrayObservable.of;
//# sourceMappingURL=of.js.map
