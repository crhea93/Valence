/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var empty = {
    closed: true,
    next: function (value) { },
    error: function (err) { throw err; },
    complete: function () { }
};
//# sourceMappingURL=Observer.js.map
