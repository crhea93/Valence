/** PURE_IMPORTS_START .._util_root PURE_IMPORTS_END */
import { root } from '../util/root';
var Symbol = root.Symbol;
export var rxSubscriber = (typeof Symbol === 'function' && typeof Symbol.for === 'function') ?
    /*@__PURE__*/ Symbol.for('rxSubscriber') : '@@rxSubscriber';
/**
 * @deprecated use rxSubscriber instead
 */
export var $$rxSubscriber = rxSubscriber;
//# sourceMappingURL=rxSubscriber.js.map
