import { MonoTypeOperatorFunction } from '../interfaces';
export declare function refCount<T>(): MonoTypeOperatorFunction<T>;
