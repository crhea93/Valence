export declare function assignImpl(target: Object, ...sources: Object[]): Object;
export declare function getAssign(root: any): any;
export declare const assign: any;
