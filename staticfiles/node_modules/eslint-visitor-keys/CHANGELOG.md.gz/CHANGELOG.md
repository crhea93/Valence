v1.1.0 - August 13, 2019

* [`9331cc0`](https://github.com/eslint/eslint-visitor-keys/commit/9331cc09e756e65b9044c9186445a474b037fac6) Update: add ImportExpression (#8) (Toru Nagashima)
* [`5967f58`](https://github.com/eslint/eslint-visitor-keys/commit/5967f583b04f17fba9226aaa394e45d476d2b8af) Chore: add supported Node.js versions to CI (#7) (Kai Cataldo)
* [`6f7c60f`](https://github.com/eslint/eslint-visitor-keys/commit/6f7c60fef2ceec9f6323202df718321cec45cab0) Upgrade: eslint-release@1.0.0 (#5) (Teddy Katz)

v1.0.0 - December 18, 2017

* 1f6bd38 Breaking: update keys (#4) (Toru Nagashima)

v0.1.0 - November 17, 2017

* 17b4a88 Chore: update `repository` field in package.json (#3) (Toru Nagashima)
* a5a026b New: eslint-visitor-keys (#1) (Toru Nagashima)
* a1a48b8 Update: Change license to Apache 2 (#2) (Ilya Volodin)
* 2204715 Initial commit (Toru Nagashima)

