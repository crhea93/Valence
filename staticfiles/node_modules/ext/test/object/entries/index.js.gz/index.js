"use strict";

var entries = require("../../../object/entries")
  , tests   = require("./_tests");

describe("object/entries/index", function () { tests(entries); });
