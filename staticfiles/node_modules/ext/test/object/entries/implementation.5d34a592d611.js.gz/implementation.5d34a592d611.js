"use strict";

var entries = require("../../../object/entries/implementation")
  , tests   = require("./_tests");

describe("object/entries/implementation", function () { tests(entries); });
