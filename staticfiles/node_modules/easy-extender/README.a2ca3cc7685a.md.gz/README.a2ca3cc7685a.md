##easy-extender [![Build Status](https://travis-ci.org/shakyShane/easy-extender.svg?branch=master)](https://travis-ci.org/shakyShane/easy-extender) [![Coverage Status](https://img.shields.io/coveralls/shakyShane/easy-extender.svg)](https://coveralls.io/r/shakyShane/easy-extender?branch=master)

Plugin + hooks system extracted from [BrowserSync](https://github.com/shakyShane/browser-sync) for general use.



