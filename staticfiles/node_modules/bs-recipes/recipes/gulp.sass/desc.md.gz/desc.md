
This example highlights both the stream support for injecting CSS, as well
as the support for calling `reload` directly following html changes.
